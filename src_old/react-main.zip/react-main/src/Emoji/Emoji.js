import './Emoji.css';

export default function Emoji() {
    return (
        <ul>
            <li>
                <button>
                <span>😀</span>
                </button>
            </li>
            <li>
                <button>
                <span>😀</span>
                </button>
            </li>
            <li>
                <button>
                <span>😀</span>
                </button>
            </li>
        </ul>
    )
};
