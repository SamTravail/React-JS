import './Footer.css';

export default function Footer() {
    return (
    <footer className='footer'>
        <p>&#169; React Company </p>
    </footer>
    )
}
